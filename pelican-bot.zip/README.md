# Pelican Discord Bot

Ein vollständiger Discord Bot in JavaScript für Pelican Panel mit Slash Commands, SQLite DB und Auto-Suspend-Funktion.

## Setup

1. `.env` ausfüllen
2. `npm install`
3. `npm start`
